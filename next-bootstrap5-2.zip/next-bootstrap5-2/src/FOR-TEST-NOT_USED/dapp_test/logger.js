import loglevel from "loglevel";

export default function logger () {
  return (
    warn,
    debug,
    info,
    error,
    trace,
    setLevel
  );
};
