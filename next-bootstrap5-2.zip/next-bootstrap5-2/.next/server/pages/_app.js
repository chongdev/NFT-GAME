/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var bootstrap_dist_css_bootstrap_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.css */ \"../node_modules/bootstrap/dist/css/bootstrap.css\");\n/* harmony import */ var bootstrap_dist_css_bootstrap_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! nextjs-progressbar */ \"nextjs-progressbar\");\n/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(nextjs_progressbar__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ethers */ \"ethers\");\n/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _src_components_userProviderContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../src/components/userProviderContext */ \"./src/components/userProviderContext.js\");\n\n\n\n\n//import { useWeb3userContext, web3UserContext } from '../src/PavanGangireddy-nextjs-ether/context/useWeb3ProviderContext';\n//import Web3ProviderContext from '../src/PavanGangireddy-nextjs-ether/context/useWeb3ProviderContext';\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{\n        Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! bootstrap/dist/js/bootstrap */ \"bootstrap/dist/js/bootstrap\", 23));\n    }, []);\n    //const web3uc = useWeb3userContext()\n    // const [config, setConfig] = useState({\n    //   etherLoaded: false,\n    //   provider: null,\n    //   signer: null,\n    //   userAddress: null,\n    // });\n    // useEffect(() => {\n    //   let instance = new ethers.providers.Web3Provider(window.ethereum);\n    //   const signer = instance.getSigner();\n    //   const getAddress = async () => {\n    //     //let userAddress = await signer.getAddress();\n    //     let userAddress = await window.ethereum.request({\n    //       method: \"eth_requestAccounts\"\n    //     });\n    //     setConfig({\n    //       provider: instance,\n    //       signer,\n    //       userAddress,\n    //       etherLoaded: true,\n    //     });\n    //   };\n    //   getAddress();\n    // }, []);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((nextjs_progressbar__WEBPACK_IMPORTED_MODULE_3___default()), {\n                color: \"#ff7a0e\",\n                startPosition: 0.5,\n                stopDelayMs: 200,\n                height: 6,\n                showOnShallow: true\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\user\\\\Desktop\\\\TEST-DAPP\\\\next-bootstrap5-2\\\\pages\\\\_app.js\",\n                lineNumber: 47,\n                columnNumber: 5\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\user\\\\Desktop\\\\TEST-DAPP\\\\next-bootstrap5-2\\\\pages\\\\_app.js\",\n                lineNumber: 54,\n                columnNumber: 1\n            }, this)\n        ]\n    }, void 0, true));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUE4QjtBQUNXO0FBQ0s7QUFFOUMsRUFBMkg7QUFDM0gsRUFBdUc7QUFFeEU7QUFDWTtBQUN5QjtTQUUzREssS0FBSyxDQUFDLENBQUMsQ0FBQ0MsU0FBUyxHQUFFQyxTQUFTLEVBQUMsQ0FBQyxFQUFFLENBQUM7SUFFeENMLGdEQUFTLEtBQU8sQ0FBQztRQUNmTSw0SkFBb0M7SUFDdEMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUVMLEVBQXFDO0lBRXJDLEVBQXlDO0lBQ3pDLEVBQXdCO0lBQ3hCLEVBQW9CO0lBQ3BCLEVBQWtCO0lBQ2xCLEVBQXVCO0lBQ3ZCLEVBQU07SUFFTixFQUFvQjtJQUNwQixFQUF1RTtJQUN2RSxFQUF5QztJQUN6QyxFQUFxQztJQUNyQyxFQUFxRDtJQUNyRCxFQUF3RDtJQUN4RCxFQUFzQztJQUN0QyxFQUFVO0lBQ1YsRUFBa0I7SUFDbEIsRUFBNEI7SUFDNUIsRUFBZ0I7SUFDaEIsRUFBcUI7SUFDckIsRUFBMkI7SUFDM0IsRUFBVTtJQUNWLEVBQU87SUFDUCxFQUFrQjtJQUNsQixFQUFVO0lBRVYsTUFBTTs7d0ZBRUhSLDJEQUFhO2dCQUNaUyxLQUFLLEVBQUMsQ0FBUztnQkFDZkMsYUFBYSxFQUFFLEdBQUc7Z0JBQ2xCQyxXQUFXLEVBQUUsR0FBRztnQkFDaEJDLE1BQU0sRUFBRSxDQUFDO2dCQUNUQyxhQUFhLEVBQUUsSUFBSTs7Ozs7O3dGQUV4QlAsU0FBUzttQkFBS0MsU0FBUzs7Ozs7Ozs7QUFZeEIsQ0FBQztBQUVELGlFQUFlRixLQUFLIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dC1ib290c3RyYXA1LTIvLi9wYWdlcy9fYXBwLmpzP2UwYWQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnXHJcbmltcG9ydCAnYm9vdHN0cmFwL2Rpc3QvY3NzL2Jvb3RzdHJhcC5jc3MnO1xyXG5pbXBvcnQgTmV4dE5wcm9ncmVzcyBmcm9tIFwibmV4dGpzLXByb2dyZXNzYmFyXCI7XHJcblxyXG4vL2ltcG9ydCB7IHVzZVdlYjN1c2VyQ29udGV4dCwgd2ViM1VzZXJDb250ZXh0IH0gZnJvbSAnLi4vc3JjL1BhdmFuR2FuZ2lyZWRkeS1uZXh0anMtZXRoZXIvY29udGV4dC91c2VXZWIzUHJvdmlkZXJDb250ZXh0JztcclxuLy9pbXBvcnQgV2ViM1Byb3ZpZGVyQ29udGV4dCBmcm9tICcuLi9zcmMvUGF2YW5HYW5naXJlZGR5LW5leHRqcy1ldGhlci9jb250ZXh0L3VzZVdlYjNQcm92aWRlckNvbnRleHQnO1xyXG5cclxuaW1wb3J0IHsgZXRoZXJzIH0gZnJvbSAnZXRoZXJzJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHdlYjNVc2VyUHJvdmlkZXIgZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL3VzZXJQcm92aWRlckNvbnRleHRcIjtcclxuXHJcbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaW1wb3J0KFwiYm9vdHN0cmFwL2Rpc3QvanMvYm9vdHN0cmFwXCIpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy9jb25zdCB3ZWIzdWMgPSB1c2VXZWIzdXNlckNvbnRleHQoKVxyXG5cclxuICAvLyBjb25zdCBbY29uZmlnLCBzZXRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gIC8vICAgZXRoZXJMb2FkZWQ6IGZhbHNlLFxyXG4gIC8vICAgcHJvdmlkZXI6IG51bGwsXHJcbiAgLy8gICBzaWduZXI6IG51bGwsXHJcbiAgLy8gICB1c2VyQWRkcmVzczogbnVsbCxcclxuICAvLyB9KTtcclxuXHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIGxldCBpbnN0YW5jZSA9IG5ldyBldGhlcnMucHJvdmlkZXJzLldlYjNQcm92aWRlcih3aW5kb3cuZXRoZXJldW0pO1xyXG4gIC8vICAgY29uc3Qgc2lnbmVyID0gaW5zdGFuY2UuZ2V0U2lnbmVyKCk7XHJcbiAgLy8gICBjb25zdCBnZXRBZGRyZXNzID0gYXN5bmMgKCkgPT4ge1xyXG4gIC8vICAgICAvL2xldCB1c2VyQWRkcmVzcyA9IGF3YWl0IHNpZ25lci5nZXRBZGRyZXNzKCk7XHJcbiAgLy8gICAgIGxldCB1c2VyQWRkcmVzcyA9IGF3YWl0IHdpbmRvdy5ldGhlcmV1bS5yZXF1ZXN0KHtcclxuICAvLyAgICAgICBtZXRob2Q6IFwiZXRoX3JlcXVlc3RBY2NvdW50c1wiXHJcbiAgLy8gICAgIH0pO1xyXG4gIC8vICAgICBzZXRDb25maWcoe1xyXG4gIC8vICAgICAgIHByb3ZpZGVyOiBpbnN0YW5jZSxcclxuICAvLyAgICAgICBzaWduZXIsXHJcbiAgLy8gICAgICAgdXNlckFkZHJlc3MsXHJcbiAgLy8gICAgICAgZXRoZXJMb2FkZWQ6IHRydWUsXHJcbiAgLy8gICAgIH0pO1xyXG4gIC8vICAgfTtcclxuICAvLyAgIGdldEFkZHJlc3MoKTtcclxuICAvLyB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgPE5leHROcHJvZ3Jlc3NcclxuICAgICAgY29sb3I9XCIjZmY3YTBlXCJcclxuICAgICAgc3RhcnRQb3NpdGlvbj17MC41fVxyXG4gICAgICBzdG9wRGVsYXlNcz17MjAwfVxyXG4gICAgICBoZWlnaHQ9ezZ9XHJcbiAgICAgIHNob3dPblNoYWxsb3c9e3RydWV9XHJcbiAgICAvPlxyXG48Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XHJcbiAgICB7LyogPHdlYjNVc2VyUHJvdmlkZXIuUHJvdmlkZXI+XHJcbiAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cclxuICAgIDwvd2ViM1VzZXJQcm92aWRlci5Qcm92aWRlcj4gKi99XHJcblxyXG5cclxuICAgIHsvKiA8d2ViM1VzZXJDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt3ZWIzdWN9PlxyXG4gICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XHJcbiAgICA8L3dlYjNVc2VyQ29udGV4dC5Qcm92aWRlcj4gKi99XHJcblxyXG4gIDwvPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTXlBcHBcclxuIl0sIm5hbWVzIjpbIk5leHROcHJvZ3Jlc3MiLCJldGhlcnMiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIndlYjNVc2VyUHJvdmlkZXIiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsImltcG9ydCIsImNvbG9yIiwic3RhcnRQb3NpdGlvbiIsInN0b3BEZWxheU1zIiwiaGVpZ2h0Iiwic2hvd09uU2hhbGxvdyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./src/components/userProviderContext.js":
/*!***********************************************!*\
  !*** ./src/components/userProviderContext.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"useWeb3UserProvider\": () => (/* binding */ useWeb3UserProvider),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ethers */ \"ethers\");\n/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _ethers_ancillary_bsc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ethers-ancillary/bsc */ \"@ethers-ancillary/bsc\");\n/* harmony import */ var _ethers_ancillary_bsc__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ethers_ancillary_bsc__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var web3modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! web3modal */ \"web3modal\");\n/* harmony import */ var web3modal__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(web3modal__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\nconst web3UserContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_3__.createContext)();\nconst web3UserProvider = ()=>{\n    const { 0: initialized , 1: setInitialized  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);\n    const { 0: provider , 1: setProvider  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();\n    const { 0: userAddress , 1: setUserAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);\n    console.log(initialized);\n    function updateProvider(_provider) {\n        setProvider(_provider);\n        console.log(\"PROVIDER: \", _provider);\n    }\n    async function getUserAddress() {\n        //if (provider.connection.url.startsWith(\"http\")) return\n        const accounts = await window.ethereum.request({\n            method: \"eth_requestAccounts\"\n        });\n        //const accounts = await provider.send(\"eth_requestAccounts\", [])\n        setUserAddress(accounts[0]);\n        console.log({\n            account: accounts\n        });\n    }\n    function setInitialProvider() {\n        const ethereum = window.ethereum;\n        console.log(ethereum);\n        const web3Modal = new (web3modal__WEBPACK_IMPORTED_MODULE_4___default())({\n            network: \"bsc-testnet\",\n            disableInjectedProvider: true,\n            cacheProvider: true,\n            providerOptions: {}\n        });\n        const provider = new ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.providers.Web3Provider(connection);\n        if (!ethereum) {\n            updateProvider(new ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.providers.Web3Provider(connection));\n            //updateProvider(new ethers.providers.JsonRpcProvider(\"http://localhost:7545\"))\n            return;\n        } else {\n            ethereum.on(\"accountsChanged\", function(accounts) {\n                setUserAddress(accounts);\n            });\n            updateProvider(new ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.providers.Web3Provider(ethereum));\n        }\n    }\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        setInitialProvider();\n        setInitialized(true);\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        if (initialized) getUserAddress();\n    }, [\n        initialized\n    ]);\n    const variables = {\n        provider,\n        userAddress\n    };\n    const functions = {\n        setUserAddress,\n        getUserAddress\n    };\n    const value = {\n        ...variables,\n        ...functions\n    };\n    return initialized ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(web3UserContext.Provider, {\n        value: value,\n        ...props\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\user\\\\Desktop\\\\TEST-DAPP\\\\next-bootstrap5-2\\\\src\\\\components\\\\userProviderContext.js\",\n        lineNumber: 66,\n        columnNumber: 24\n    }, undefined) : null;\n};\nconst useWeb3UserProvider = ()=>{\n    return (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(web3UserContext);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (web3UserProvider);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91c2VyUHJvdmlkZXJDb250ZXh0LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBK0I7QUFDd0I7QUFDZTtBQUNyQztBQUVqQyxLQUFLLENBQUNPLGVBQWUsaUJBQUdMLG9EQUFhO0FBRXJDLEtBQUssQ0FBQ00sZ0JBQWdCLE9BQVMsQ0FBQztJQUU5QixLQUFLLE1BQUVDLFdBQVcsTUFBRUMsY0FBYyxNQUFJTCwrQ0FBUSxDQUFDLEtBQUs7SUFDcEQsS0FBSyxNQUFFTSxRQUFRLE1BQUVDLFdBQVcsTUFBSVAsK0NBQVE7SUFDeEMsS0FBSyxNQUFFUSxXQUFXLE1BQUVDLGNBQWMsTUFBSVQsK0NBQVEsQ0FBQyxDQUFDLENBQUM7SUFDakRVLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDUCxXQUFXO2FBRWRRLGNBQWMsQ0FBQ0MsU0FBUyxFQUFFLENBQUM7UUFDbENOLFdBQVcsQ0FBQ00sU0FBUztRQUNyQkgsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBWSxhQUFFRSxTQUFTO0lBQ3JDLENBQUM7bUJBRWNDLGNBQWMsR0FBRyxDQUFDO1FBQy9CLEVBQXdEO1FBQ3hELEtBQUssQ0FBQ0MsUUFBUSxHQUFHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE9BQU8sQ0FBQyxDQUFDO1lBQUNDLE1BQU0sRUFBRSxDQUFxQjtRQUFDLENBQUM7UUFDaEYsRUFBaUU7UUFDakVWLGNBQWMsQ0FBQ00sUUFBUSxDQUFDLENBQUM7UUFDekJMLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQUM7WUFBQ1MsT0FBTyxFQUFFTCxRQUFRO1FBQUMsQ0FBQztJQUNuQyxDQUFDO2FBRVFNLGtCQUFrQixHQUFHLENBQUM7UUFFN0IsS0FBSyxDQUFDSixRQUFRLEdBQUdELE1BQU0sQ0FBQ0MsUUFBUTtRQUNoQ1AsT0FBTyxDQUFDQyxHQUFHLENBQUNNLFFBQVE7UUFDcEIsS0FBSyxDQUFDSyxTQUFTLEdBQUcsR0FBRyxDQUFDckIsa0RBQVMsQ0FBQyxDQUFDO1lBQy9Cc0IsT0FBTyxFQUFFLENBQWE7WUFDdEJDLHVCQUF1QixFQUFFLElBQUk7WUFDN0JDLGFBQWEsRUFBRSxJQUFJO1lBQ25CQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBQ3JCLENBQUM7UUFDRCxLQUFLLENBQUNwQixRQUFRLEdBQUcsR0FBRyxDQUFDWCxpRUFBNkIsQ0FBQ2tDLFVBQVU7UUFFN0QsRUFBRSxHQUFHWixRQUFRLEVBQUUsQ0FBQztZQUNkTCxjQUFjLENBQUMsR0FBRyxDQUFDakIsaUVBQTZCLENBQUNrQyxVQUFVO1lBQzNELEVBQStFO1lBQy9FLE1BQU07UUFDUixDQUFDLE1BQU0sQ0FBQztZQUNOWixRQUFRLENBQUNhLEVBQUUsQ0FBQyxDQUFpQixrQkFBRSxRQUFRLENBQUVmLFFBQVEsRUFBRSxDQUFDO2dCQUNsRE4sY0FBYyxDQUFDTSxRQUFRO1lBQ3pCLENBQUM7WUFDREgsY0FBYyxDQUFDLEdBQUcsQ0FBQ2pCLGlFQUE2QixDQUFDc0IsUUFBUTtRQUMzRCxDQUFDO0lBQ0gsQ0FBQztJQUVEbEIsZ0RBQVMsS0FBTyxDQUFDO1FBQ2ZzQixrQkFBa0I7UUFDbEJoQixjQUFjLENBQUMsSUFBSTtJQUNyQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRUxOLGdEQUFTLEtBQU8sQ0FBQztRQUNmLEVBQUUsRUFBRUssV0FBVyxFQUFFVSxjQUFjO0lBQ2pDLENBQUMsRUFBRSxDQUFDVjtRQUFBQSxXQUFXO0lBQUEsQ0FBQztJQUVoQixLQUFLLENBQUMyQixTQUFTLEdBQUcsQ0FBQztRQUFDekIsUUFBUTtRQUFFRSxXQUFXO0lBQUMsQ0FBQztJQUMzQyxLQUFLLENBQUN3QixTQUFTLEdBQUcsQ0FBQztRQUFDdkIsY0FBYztRQUFFSyxjQUFjO0lBQUMsQ0FBQztJQUVwRCxLQUFLLENBQUNtQixLQUFLLEdBQUcsQ0FBQztXQUFJRixTQUFTO1dBQUtDLFNBQVM7SUFBQyxDQUFDO0lBRTVDLE1BQU0sQ0FBQzVCLFdBQVcsK0VBQUlGLGVBQWUsQ0FBQ2dDLFFBQVE7UUFBQ0QsS0FBSyxFQUFFQSxLQUFLO1dBQU1FLEtBQUs7Ozs7O29CQUFPLElBQUk7QUFDbkYsQ0FBQztBQUVNLEtBQUssQ0FBQ0MsbUJBQW1CLE9BQVMsQ0FBQztJQUN4QyxNQUFNLENBQUN0QyxpREFBVSxDQUFDSSxlQUFlO0FBQ25DLENBQUM7QUFFRCxpRUFBZUMsZ0JBQWdCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dC1ib290c3RyYXA1LTIvLi9zcmMvY29tcG9uZW50cy91c2VyUHJvdmlkZXJDb250ZXh0LmpzP2YzZTgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZXRoZXJzIH0gZnJvbSBcImV0aGVyc1wiXHJcbmltcG9ydCB7IEJzY3NjYW5Qcm92aWRlciB9IGZyb20gXCJAZXRoZXJzLWFuY2lsbGFyeS9ic2NcIjtcclxuaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiXHJcbmltcG9ydCBXZWIzTW9kYWwgZnJvbSAnd2ViM21vZGFsJ1xyXG5cclxuY29uc3Qgd2ViM1VzZXJDb250ZXh0ID0gY3JlYXRlQ29udGV4dCgpXHJcblxyXG5jb25zdCB3ZWIzVXNlclByb3ZpZGVyID0gKCkgPT4ge1xyXG5cclxuICBjb25zdCBbaW5pdGlhbGl6ZWQsIHNldEluaXRpYWxpemVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcHJvdmlkZXIsIHNldFByb3ZpZGVyXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW3VzZXJBZGRyZXNzLCBzZXRVc2VyQWRkcmVzc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc29sZS5sb2coaW5pdGlhbGl6ZWQpO1xyXG5cclxuICBmdW5jdGlvbiB1cGRhdGVQcm92aWRlcihfcHJvdmlkZXIpIHtcclxuICAgIHNldFByb3ZpZGVyKF9wcm92aWRlcik7XHJcbiAgICBjb25zb2xlLmxvZyhcIlBST1ZJREVSOiBcIiwgX3Byb3ZpZGVyKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFVzZXJBZGRyZXNzKCkge1xyXG4gICAgLy9pZiAocHJvdmlkZXIuY29ubmVjdGlvbi51cmwuc3RhcnRzV2l0aChcImh0dHBcIikpIHJldHVyblxyXG4gICAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCB3aW5kb3cuZXRoZXJldW0ucmVxdWVzdCh7IG1ldGhvZDogXCJldGhfcmVxdWVzdEFjY291bnRzXCIgfSk7XHJcbiAgICAvL2NvbnN0IGFjY291bnRzID0gYXdhaXQgcHJvdmlkZXIuc2VuZChcImV0aF9yZXF1ZXN0QWNjb3VudHNcIiwgW10pXHJcbiAgICBzZXRVc2VyQWRkcmVzcyhhY2NvdW50c1swXSk7XHJcbiAgICBjb25zb2xlLmxvZyh7IGFjY291bnQ6IGFjY291bnRzIH0pO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gc2V0SW5pdGlhbFByb3ZpZGVyKCkge1xyXG5cclxuICAgIGNvbnN0IGV0aGVyZXVtID0gd2luZG93LmV0aGVyZXVtXHJcbiAgICBjb25zb2xlLmxvZyhldGhlcmV1bSk7XHJcbiAgICBjb25zdCB3ZWIzTW9kYWwgPSBuZXcgV2ViM01vZGFsKHtcclxuICAgICAgbmV0d29yazogXCJic2MtdGVzdG5ldFwiLCAvLyBvcHRpb25hbFxyXG4gICAgICBkaXNhYmxlSW5qZWN0ZWRQcm92aWRlcjogdHJ1ZSwgLy8gb3B0aW9uYWxcclxuICAgICAgY2FjaGVQcm92aWRlcjogdHJ1ZSwgLy8gb3B0aW9uYWxcclxuICAgICAgcHJvdmlkZXJPcHRpb25zOiB7fSwgLy8gcmVxdWlyZWRcclxuICAgIH0pO1xyXG4gICAgY29uc3QgcHJvdmlkZXIgPSBuZXcgZXRoZXJzLnByb3ZpZGVycy5XZWIzUHJvdmlkZXIoY29ubmVjdGlvbilcclxuXHJcbiAgICBpZiAoIWV0aGVyZXVtKSB7XHJcbiAgICAgIHVwZGF0ZVByb3ZpZGVyKG5ldyBldGhlcnMucHJvdmlkZXJzLldlYjNQcm92aWRlcihjb25uZWN0aW9uKSlcclxuICAgICAgLy91cGRhdGVQcm92aWRlcihuZXcgZXRoZXJzLnByb3ZpZGVycy5Kc29uUnBjUHJvdmlkZXIoXCJodHRwOi8vbG9jYWxob3N0Ojc1NDVcIikpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZXRoZXJldW0ub24oXCJhY2NvdW50c0NoYW5nZWRcIiwgZnVuY3Rpb24gKGFjY291bnRzKSB7XHJcbiAgICAgICAgc2V0VXNlckFkZHJlc3MoYWNjb3VudHMpXHJcbiAgICAgIH0pXHJcbiAgICAgIHVwZGF0ZVByb3ZpZGVyKG5ldyBldGhlcnMucHJvdmlkZXJzLldlYjNQcm92aWRlcihldGhlcmV1bSkpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0SW5pdGlhbFByb3ZpZGVyKClcclxuICAgIHNldEluaXRpYWxpemVkKHRydWUpXHJcbiAgfSwgW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaW5pdGlhbGl6ZWQpIGdldFVzZXJBZGRyZXNzKClcclxuICB9LCBbaW5pdGlhbGl6ZWRdKVxyXG5cclxuICBjb25zdCB2YXJpYWJsZXMgPSB7IHByb3ZpZGVyLCB1c2VyQWRkcmVzcyB9XHJcbiAgY29uc3QgZnVuY3Rpb25zID0geyBzZXRVc2VyQWRkcmVzcywgZ2V0VXNlckFkZHJlc3MgfVxyXG5cclxuICBjb25zdCB2YWx1ZSA9IHsgLi4udmFyaWFibGVzLCAuLi5mdW5jdGlvbnMgfVxyXG5cclxuICByZXR1cm4gaW5pdGlhbGl6ZWQgPyA8d2ViM1VzZXJDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt2YWx1ZX0gey4uLnByb3BzfSAvPiA6IG51bGxcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHVzZVdlYjNVc2VyUHJvdmlkZXIgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIHVzZUNvbnRleHQod2ViM1VzZXJDb250ZXh0KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCB3ZWIzVXNlclByb3ZpZGVyXHJcblxyXG4vLyBXSEVOIE1FVFJBTUFTSyBJUyBTRVQgVE8gV1JPTkcgTkVUV09SSyBjb250YWN0Lm1lc3NnZSgpIGVycm9ycyBvdXQiXSwibmFtZXMiOlsiZXRoZXJzIiwiQnNjc2NhblByb3ZpZGVyIiwiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIldlYjNNb2RhbCIsIndlYjNVc2VyQ29udGV4dCIsIndlYjNVc2VyUHJvdmlkZXIiLCJpbml0aWFsaXplZCIsInNldEluaXRpYWxpemVkIiwicHJvdmlkZXIiLCJzZXRQcm92aWRlciIsInVzZXJBZGRyZXNzIiwic2V0VXNlckFkZHJlc3MiLCJjb25zb2xlIiwibG9nIiwidXBkYXRlUHJvdmlkZXIiLCJfcHJvdmlkZXIiLCJnZXRVc2VyQWRkcmVzcyIsImFjY291bnRzIiwid2luZG93IiwiZXRoZXJldW0iLCJyZXF1ZXN0IiwibWV0aG9kIiwiYWNjb3VudCIsInNldEluaXRpYWxQcm92aWRlciIsIndlYjNNb2RhbCIsIm5ldHdvcmsiLCJkaXNhYmxlSW5qZWN0ZWRQcm92aWRlciIsImNhY2hlUHJvdmlkZXIiLCJwcm92aWRlck9wdGlvbnMiLCJwcm92aWRlcnMiLCJXZWIzUHJvdmlkZXIiLCJjb25uZWN0aW9uIiwib24iLCJ2YXJpYWJsZXMiLCJmdW5jdGlvbnMiLCJ2YWx1ZSIsIlByb3ZpZGVyIiwicHJvcHMiLCJ1c2VXZWIzVXNlclByb3ZpZGVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/userProviderContext.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "../node_modules/bootstrap/dist/css/bootstrap.css":
/*!********************************************************!*\
  !*** ../node_modules/bootstrap/dist/css/bootstrap.css ***!
  \********************************************************/
/***/ (() => {



/***/ }),

/***/ "@ethers-ancillary/bsc":
/*!****************************************!*\
  !*** external "@ethers-ancillary/bsc" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@ethers-ancillary/bsc");

/***/ }),

/***/ "bootstrap/dist/js/bootstrap":
/*!**********************************************!*\
  !*** external "bootstrap/dist/js/bootstrap" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("bootstrap/dist/js/bootstrap");

/***/ }),

/***/ "ethers":
/*!*************************!*\
  !*** external "ethers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("ethers");

/***/ }),

/***/ "nextjs-progressbar":
/*!*************************************!*\
  !*** external "nextjs-progressbar" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-progressbar");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "web3modal":
/*!****************************!*\
  !*** external "web3modal" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("web3modal");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();